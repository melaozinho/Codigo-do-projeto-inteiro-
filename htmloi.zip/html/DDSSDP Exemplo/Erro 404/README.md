<p align="center">
  <a href="https://filipealvesdef.github.io/yellowball-game-yt/index.html">
    <img src="https://github.com/filipealvesdef/yellowball-game-yt/blob/master/yellowball-preview.gif?raw=true">
  </a>
</p>

# Yellowball Runner

A game implemented for didactic purposes on a [YouTube tutorial series](https://www.youtube.com/watch?v=z3r8up9cz3w&list=PL1EkVGo1AQ0Hsqhvjm4khfp6innDjpj9J), available only in portuguese.
Feel free to use it and share as you wish but it would be cool if you give me due credits :)

### Note
This was implemented when I was graduating and this code is messy. I did not refactor it for being consistent with the videos.
