console.log('Execundo Jogo na área [index.html/jogo.js]');

const sprites = nem Image();
sprites.src= './sprites.png'

const canvas = document.querySelector('canvas');
const contexto = canvas.getContext('2d')